$(document).ready(function () {
  new View(new Calculator());
});
